module.exports = require('../lib/plugins/html-parser')
