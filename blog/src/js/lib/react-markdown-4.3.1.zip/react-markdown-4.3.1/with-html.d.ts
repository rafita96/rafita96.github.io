import {Component} from 'react'
import ReactMarkdownRoot = require('react-markdown')

declare class ReactMarkdown extends Component<ReactMarkdownRoot.ReactMarkdownProps, {}> {}
export = ReactMarkdown
