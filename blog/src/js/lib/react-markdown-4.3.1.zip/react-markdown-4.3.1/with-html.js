module.exports = require('./lib/with-html')
