const HtmlParser = '__RMD_HTML_PARSER__'

exports.HtmlParser = typeof Symbol === 'undefined' ? HtmlParser : Symbol(HtmlParser)
