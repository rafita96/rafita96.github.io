const visit = require('unist-util-visit')

exports.ofType = function(types, mode) {
  return function(node) {
    types.forEach(type => visit(node, type, disallow, true))
    return node
  }

  function disallow(node, index, parent) {
    if (parent) {
      untangle(node, index, parent, mode)
    }
  }
}

exports.ifNotMatch = function(allowNode, mode) {
  return function(node) {
    visit(node, disallow, true)
    return node
  }

  function disallow(node, index, parent) {
    if (parent && !allowNode(node, index, parent)) {
      untangle(node, index, parent, mode)
    }
  }
}

function untangle(node, index, parent, mode) {
  if (mode === 'remove') {
    parent.children.splice(index, 1)
  } else if (mode === 'unwrap') {
    let args = [index, 1]

    if (node.children) {
      args = args.concat(node.children)
    }

    Array.prototype.splice.apply(parent.children, args)
  }
}
